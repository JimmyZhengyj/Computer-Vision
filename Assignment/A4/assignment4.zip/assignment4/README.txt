This is the Assignment 4 for CSC420.

Files:
1. Images folder contains all the result images.
2. Q4.ipynb contains the code for question 4.
3. Q5.ipynb contains the code for question 5.


