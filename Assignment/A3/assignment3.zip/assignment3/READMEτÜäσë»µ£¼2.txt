This is the for Assignment 3 of CSC420.

(1) Code
The code for q1,q3,q4 are in "Q1.ipynb","Q3.ipynb", "Q4.ipynb" seperately.

(2) Txt files
The txt files of Normalized Histogram for Question 3 are in the "TXT" folder.

(3) Images
The Result images are in the "image" folder.
The original images for Q3,Q4 are in "Q3" and "Q4" folder.
