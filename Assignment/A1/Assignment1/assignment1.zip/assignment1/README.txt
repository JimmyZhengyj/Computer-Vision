
This is a README file. 

RUN the code:
All the codes are in the file Part2.ipynb . Just run it block by block will return the required images. 

Result:
Input an image, it will return the corresponding three images after each three steps: blurred image, image by gradient magnitude and image by detecting edges.

Change input:
Change the image name in the last block: Image = cv2.imread(), change the name inside the bracket.

Functions:
The first block import required libraries.
The 2-4 blocks corresponds to step 1 to 3.
The final block returns the result.



