
This is a README file. 

RUN the code:
All the codes are in the file A2.ipynb . Just run it block by block will train the neural networks and return the train result. 

Result:
It will show the loss and accuracy for training set, validation set after each epoch. After the training process finishes, it will return the test accuracy as required. 
The plot part will show how training loss and validation loss changes after each epoch. 

Change input:
Change the model parameters inside the Model. Change the number inside the nn.Linear to change the number of hidden units.

Functions:
The first part is for task 1: data processing.
The second part is for task 2-4: training models with different parameters. 
The final part is for task 5: adding the pool layer.